# legacystamps
A tiny Python module to allow easy retrieval of a cutout from the Legacy survey.
